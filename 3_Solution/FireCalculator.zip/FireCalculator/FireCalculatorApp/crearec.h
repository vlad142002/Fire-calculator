#ifndef CREAREC_H
#define CREAREC_H

#include <QDialog>
#include "conectare.h"
namespace Ui {
class creareC;
}

class creareC : public QDialog
{
    Q_OBJECT

public:
    explicit creareC(QWidget *parent = nullptr);
    ~creareC();

private slots:

    void on_creareParola_2_textChanged(const QString &arg1);




    void on_butonCreareCont_clicked();



    void on_buton_inapoi_clicked();


    void on_creareNume_textEdited(const QString &arg1);

    void on_crearePrenume_textEdited(const QString &arg1);

    void on_creareUserName_textEdited(const QString &arg1);

private:
    Ui::creareC *ui;
    conectare conexiune;
};

#endif // CREAREC_H

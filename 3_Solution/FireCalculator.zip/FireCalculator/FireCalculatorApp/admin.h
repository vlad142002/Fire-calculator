#ifndef ADMIN_H
#define ADMIN_H

#include"protocoale.h"
#include <QDialog>

#include <QDialog>
#include<QVBoxLayout>
#include<QToolButton>
#include<QDate>
#include <QFont>
#include <QDateTime>
#include <QLabel>
#include <QTimer>
#include"protocoale.h"
#include"QScrollArea"

namespace Ui {
class Admin;
}

class Admin : public QDialog
{
    Q_OBJECT

public:
    explicit Admin(QWidget *parent = nullptr);
    ~Admin();

private slots:
   void on_iesire_clicked();

   void afisareClient(QString user);

   void on_veziConturi_clicked();

   void on_veziCereri_clicked();


   void on_iesire_2_clicked();

   void on_Cauta_clicked();

   void generazaClienti();



   void buton2salvari(int row);
   void buton1salvari(int row);

   void on_campCautare_textEdited(const QString &arg1);

   private:
    Ui::Admin *ui;
    protocoale prot;
    QString user;


    QScrollArea* scrollArea;
    QWidget* scrollableContent;

    QVBoxLayout* layout;
    std::vector<QLabel*> labels;
    std::vector<QPushButton*> buttons1;
    std::vector<QPushButton*> buttons2;
    std::vector<QString> useri;

};

#endif // ADMIN_H

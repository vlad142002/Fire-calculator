#include "admin.h"
#include "ui_admin.h"
#include "mainwindow.h"
#include"ui_mainwindow.h"

Admin::Admin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Admin)
{
    ui->setupUi(this);
    this->setWindowTitle("Admin");
    ui->afisareCont->hide();


    ui->veziCereri->hide();
    ui->eroare->hide();

}

Admin::~Admin()
{
    delete ui;
}

void Admin::on_iesire_clicked()
{
    this->close();
    MainWindow *fereastraLogare=new MainWindow();
    fereastraLogare->show();
}

void Admin::afisareClient(QString user)
{

    QString prot2=prot.protocol2(user);
    QStringList parts2 =prot2.split('`');

    if(parts2[2]=='1')
    {
        QString prot4=prot.protocol4(user);

        QStringList parts4 =prot4.split('`');
        ui->userName->setText("userName: "+parts4[1]);
        ui->nume->setText("nume: "+parts4[2]);
        ui->prenume->setText("prenume"+ parts4[3]);
        ui->dataNastere->setText("data nastere: "+parts4[4]+"-"+parts4[5]+"-"+parts4[6]);
        this->user=parts4[1];


        ui->afisareCont->show();
        this->scrollArea->hide();
    }
    else
        ui->eroare->show();

}

void Admin::on_veziConturi_clicked()
{
    ui->afisareCont->hide();
    this->generazaClienti();
}


void Admin::on_veziCereri_clicked()
{
    ui->afisareCont->hide();

}



void Admin::on_iesire_2_clicked()
{
    ui->afisareCont->hide();
    QString mesajPrimit=prot.protocol9(this->user);

}


void Admin::on_Cauta_clicked()
{
    this->afisareClient(ui->campCautare->text());
}

void Admin::generazaClienti()
{
    scrollArea = new QScrollArea(this);
    scrollArea->setGeometry(10,90,785,495);
    scrollArea->setStyleSheet("background-color: transparent;");

    scrollableContent = new QWidget(scrollArea);
    layout = new QVBoxLayout(scrollableContent);


    QString cadruPrimit=prot.protocolU();
    QStringList parts = cadruPrimit.split('`');

    int numButoane=parts[1].toInt();

    for (int i = 0; i < numButoane; ++i) {
    QHBoxLayout *rowLayout = new QHBoxLayout();
    QString ceAfisez="utilizatorul "+parts[2+i];
    useri.push_back(parts[2+i]);

    QLabel* label = new QLabel(ceAfisez, scrollableContent);
    QPushButton* button1 = new QPushButton("Șterge", scrollableContent);
    QPushButton* button2 = new QPushButton("Vezi", scrollableContent);

    label->setFixedSize(400, 45);
    label->setStyleSheet("color: white; background-color:#8AA69B;"
                         " border-radius: 4px;font-size: 14px; padding: 10px 20px;font-weight: bold;");

    button1->setFixedSize(100,45);
    button1->setStyleSheet("QPushButton {background-color: #4285F4; color: white;border: none;border-radius: 4px;padding: 10px 20px;font-size: 14px;font-weight: bold;}"
            "QPushButton:hover {background-color: #3367D6;}"
            "QPushButton:pressed {background-color: #254EDA;}");
    button2->setFixedSize(100,45);
    button2->setStyleSheet("QPushButton {background-color: #4285F4; color: white;border: none;border-radius: 4px;padding: 10px 20px;font-size: 14px;font-weight: bold;}"
                           "QPushButton:hover {background-color: #3367D6;}"
                           "QPushButton:pressed {background-color: #254EDA;}");

    rowLayout->addWidget(label);
    rowLayout->addWidget(button1);
    rowLayout->addWidget(button2);



    layout->addLayout(rowLayout);

    labels.push_back(label);
    buttons1.push_back(button1);
    buttons2.push_back(button2);
    }



    scrollArea->setWidget(scrollableContent);

    for (int row = 0; row < buttons2.size(); ++row) {
    connect(buttons2[row], &QPushButton::clicked, [this, row]() {buton2salvari(row);});
    }
    for (int row = 0; row < buttons1.size(); ++row) {
    connect(buttons1[row], &QPushButton::clicked, [this, row]() {buton1salvari(row);});
    }
    scrollableContent->show();
    scrollArea->show();




    scrollArea->setWidget(scrollableContent);

    for (int row = 0; row < buttons2.size(); ++row) {
    connect(buttons2[row], &QPushButton::clicked, [this, row]() {buton2salvari(row);});
    }
    for (int row = 0; row < buttons1.size(); ++row) {
    connect(buttons1[row], &QPushButton::clicked, [this, row]() {buton1salvari(row);});
    }
    scrollableContent->show();
    scrollArea->show();


}

void Admin::buton2salvari(int row)
{
    this->afisareClient(useri[row]);
}

void Admin::buton1salvari(int row)
{
    ui->afisareCont->hide();
    QString mesajPrimit=prot.protocol9(useri[row]);
    this->scrollArea->hide();
    this->generazaClienti();
}


void Admin::on_campCautare_textEdited(const QString &arg1)
{
    ui->eroare->hide();
}


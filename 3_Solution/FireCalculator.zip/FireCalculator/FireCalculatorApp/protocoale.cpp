
#include "protocoale.h"
#include "qdebug.h"

protocoale::protocoale()
{

}

QString protocoale::protocolX(QString cadru)
{
    QString primit;

    qDebug()<<"Se apeleaza protocolul X:";
    qDebug()<<"S-a transmis: "<<cadru;

    QByteArray byteArray=cadru.toUtf8();
    char* cadruChar=byteArray.data();




    if (conect.checkConnection()) {
        primit=this->conect.connectServer(cadruChar);
    } else {
        primit="eroare";
    }


    //primit="x`sara`1`4500`3000`0`0`0`6`80`21`38`556301`18`18000`37080`57304`78743`101467`125555`151089`178154`206843`237254`269489`303658`339878`378271`418967`462105`507831`556301`";

    qDebug()<<"S-a primit: "<<primit;

    if(primit[0]!='x' and primit[1]!='`')
    {
        primit="eroare";
    }

    return primit;
}

QString protocoale::protocolS(QString cadru)
{
    QString primit;

    qDebug()<<"Se apeleaza protocolul S:";
    qDebug()<<"S-a transmis: "<<cadru;

    QByteArray byteArray=cadru.toUtf8();
    char* cadruChar=byteArray.data();

    if (conect.checkConnection()) {
        primit=this->conect.connectServer(cadruChar);
    } else {
        primit="eroare";
    }


    //primit="test prtocol s";

    qDebug()<<"S-a primit: "<<primit;

    QStringList parts = primit.split('`');

    if(primit[0]!='s' and primit[1]!='`')
    {
        primit="eroare";
    }
    if(parts[2]=="0")
    {
        primit="eroare";
    }

    return primit;
}

QString protocoale::protocolD(QString cadru)
{
    QString primit;

    qDebug()<<"Se apeleaza protocolul D:";
    qDebug()<<"S-a transmis: "<<cadru;

    QByteArray byteArray=cadru.toUtf8();
    char* cadruChar=byteArray.data();

    if (conect.checkConnection()) {
        primit=this->conect.connectServer(cadruChar);
    } else {
        primit="eroare";
    }


   // primit="test prtocol d";

    qDebug()<<"S-a primit: "<<primit;

    if(primit[0]!='d' and primit[1]!='`')
    {
        primit="eroare";
    }

    return primit;
}

QString protocoale::protocolG(QString user)
{
    QString primit;
    QString cadru;
    cadru="G`"+user+"`";

    qDebug()<<"Se apeleaza protocolul G:";
    qDebug()<<"S-a transmis: "<<cadru;

    QByteArray byteArray=cadru.toUtf8();
    char* cadruChar=byteArray.data();

    char mesajVerificare[20];
    strcpy(mesajVerificare,"qCheckConnection");
    //primit="G`sara`0`";


    if (conect.checkConnection()) {
        primit=this->conect.connectServer(cadruChar);
    } else {
        primit="eroare";
    }


    qDebug()<<"S-a primit: "<<primit;

    if(primit[0]!='G' and primit[1]!='`')
    {
        primit="eroare";
    }

    return primit;
}

QString protocoale::protocol4(QString user)
{

        QString primit;
        QString cadru;
        cadru="4`"+user+"`";

        qDebug()<<"Se apeleaza protocolul 4:";
        qDebug()<<"S-a transmis: "<<cadru;

        QByteArray byteArray=cadru.toUtf8();
        char* cadruChar=byteArray.data();

        char mesajVerificare[20];
        strcpy(mesajVerificare,"qCheckConnection");



        if (conect.checkConnection()) {
            primit=this->conect.connectServer(cadruChar);
        } else {
            primit="4`userName`nume`prenume`zi`luna`an`";
        }


        qDebug()<<"S-a primit: "<<primit;

        if(primit[0]!='4' and primit[1]!='`')
        {
            primit="4`userName`nume`prenume`zi`luna`an`";

        }

        return primit;
}

QString protocoale::protocol1(QString user,QString parola)
{
        QString primit;
        QString cadru;
        cadru="1`"+user+"`"+parola+'`';

        qDebug()<<"Se apeleaza protocolul 1:";
        qDebug()<<"S-a transmis: "<<cadru;

        QByteArray byteArray=cadru.toUtf8();
        char* cadruChar=byteArray.data();

        char mesajVerificare[20];
        strcpy(mesajVerificare,"qCheckConnection");

        if (conect.checkConnection()) {
            primit=this->conect.connectServer(cadruChar);
        } else {
            primit="1`"+user+"`0`";
        }

        qDebug()<<"S-a primit: "<<primit;

        if(primit[0]!='1' and primit[1]!='`')
        {
            primit="1`"+user+"`0`";

        }

        return primit;

}

QString protocoale::protocol2(QString user)
{

        QString primit;
        QString cadru;
        cadru="2`"+user+"`";

        qDebug()<<"Se apeleaza protocolul 2:";
        qDebug()<<"S-a transmis: "<<cadru;

        QByteArray byteArray=cadru.toUtf8();
        char* cadruChar=byteArray.data();

        char mesajVerificare[20];
        strcpy(mesajVerificare,"qCheckConnection");



        if (conect.checkConnection()) {
            primit=this->conect.connectServer(cadruChar);
        } else {
            primit="2`userName`0`";
        }


        qDebug()<<"S-a primit: "<<primit;

        if(primit[0]!='2' and primit[1]!='`')
        {
            primit="2`userName`0`";

        }

        return primit;
}

QString protocoale::protocolg(QString user,QString save)
{
        QString primit;
        QString cadru;
        cadru="g`"+user+"`"+save+'`';

        qDebug()<<"Se apeleaza protocolul g:";
        qDebug()<<"S-a transmis: "<<cadru;

        QByteArray byteArray=cadru.toUtf8();
        char* cadruChar=byteArray.data();

        char mesajVerificare[20];
        strcpy(mesajVerificare,"qCheckConnection");

        if (conect.checkConnection()) {
            primit=this->conect.connectServer(cadruChar);
        } else {
            primit="g`"+user+"`0`";
        }

        qDebug()<<"S-a primit: "<<primit;

        if(primit[0]!='g' and primit[1]!='`')
        {
            primit="g`"+user+"`0`";

        }

        return primit;


}

QString protocoale::protocolA(QString user,QString parola)
{
        QString primit;
        QString cadru;
        cadru="a`"+user+"`"+parola+'`';

        qDebug()<<"Se apeleaza protocolul a:";
        qDebug()<<"S-a transmis: "<<cadru;

        QByteArray byteArray=cadru.toUtf8();
        char* cadruChar=byteArray.data();

        char mesajVerificare[20];
        strcpy(mesajVerificare,"qCheckConnection");

        if (conect.checkConnection()) {
            primit=this->conect.connectServer(cadruChar);
        } else {
            primit="a`"+user+"`0`";
        }

        qDebug()<<"S-a primit: "<<primit;

        if(primit[0]!='a' and primit[1]!='`')
        {
            primit="a`"+user+"`0`";

        }

        return primit;


}

QString protocoale::protocol9(QString user)
{
        QString primit;
        QString cadru;
        cadru="9`"+user+"`";

        qDebug()<<"Se apeleaza protocolul 9:";
        qDebug()<<"S-a transmis: "<<cadru;

        QByteArray byteArray=cadru.toUtf8();
        char* cadruChar=byteArray.data();

        char mesajVerificare[20];
        strcpy(mesajVerificare,"qCheckConnection");



        if (conect.checkConnection()) {
            primit=this->conect.connectServer(cadruChar);
        } else {
            primit="9`userName`0`";
        }


        qDebug()<<"S-a primit: "<<primit;

        if(primit[0]!='9' and primit[1]!='`')
        {
            primit="9`userName`0`";

        }

        return primit;

}

QString protocoale::protocolU()
{
        QString primit;
        QString cadru;
        cadru="u`";;

        qDebug()<<"Se apeleaza protocolul u:";
        qDebug()<<"S-a transmis: "<<cadru;

        QByteArray byteArray=cadru.toUtf8();
        char* cadruChar=byteArray.data();

        char mesajVerificare[20];
        strcpy(mesajVerificare,"qCheckConnection");



        if (conect.checkConnection()) {
            primit=this->conect.connectServer(cadruChar);
        } else {
            primit="u`userName`0`";
        }


        qDebug()<<"S-a primit: "<<primit;

        if(primit[0]!='u' and primit[1]!='`')
        {
            primit="u`userName`0`";

        }

        return primit;


}

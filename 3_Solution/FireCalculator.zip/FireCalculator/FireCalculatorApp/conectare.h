
#ifndef CONECTARE_H
#define CONECTARE_H

#include <qstring>


class conectare
{
public:
    conectare();
    QString connectServer(char* sendbuff);
    bool checkConnection();
};

#endif // CONECTARE_H

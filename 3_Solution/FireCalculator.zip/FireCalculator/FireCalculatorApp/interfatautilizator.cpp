#include "interfatautilizator.h"
#include "ui_interfatautilizator.h"
#include"mainwindow.h"
#include"ui_mainwindow.h"
#include"conectare.h"
#include"protocoale.h"
#include<QtCharts/QtCharts>
#include <QtCharts/QLineSeries>
#include <QtCharts/QChartView>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>



interfataUtilizator::interfataUtilizator(QString user,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::interfataUtilizator)
{

    this->userName=user;
    ui->setupUi(this);


    //this->scrollableContent->hide();
    //this->scrollArea->hide();


    ui->fereastraAfisareSolutie->hide();
    ui->fereastraCreareSolutie->hide();
    ui->linieText->setEchoMode(QLineEdit::Normal);
    ui->linieText_2->setEchoMode(QLineEdit::Normal);
    ui->linieText_2->hide();
    ui->camp1venitLunar->hide();
    ui->camp2cheltuieli->hide();
    ui->camp3economii->hide();
    ui->camp4venitPasiv->hide();
    ui->camp5mostenire->hide();
    ui->camp6dobanda->hide();
    ui->camp7durataViata->hide();
    ui->negCreare->hide();
    ui->accCreare->hide();
    ui->descriere1->hide();
    ui->descriere1_2->hide();
    ui->descriere3->hide();
    ui->dobanda->hide();
    ui->mostenire->hide();
    ui->economii->hide();
    ui->eroare->hide();
    ui->optionalIF->hide();
    ui->durataViata->hide();

    ui->afirmare->hide();
    ui->intrebare->hide();
    ui->negare->hide();
    ui->linieText->hide();
    ui->dateEdit->hide();

    QString b=protocol.protocol4(this->userName);

    QStringList parts = b.split('`');
    if(parts[0]=="4" and parts[1]==this->userName)
    {
        this->nume=parts[2];
        this->prenume=parts[3];
        ui->afisareNume->setText("Bine ai venit, "+this->nume+" "+this->prenume);
    }
    else
    {
        qDebug()<<"Eroare la prot 4 de preluare a datelor de la client";
        this->close();
        MainWindow *fereastraLogare=new MainWindow();
        fereastraLogare->show();
    }
    this->actualizeazaSalvari();


}

interfataUtilizator::~interfataUtilizator()
{
    delete ui;
}

void interfataUtilizator::on_butonExit_clicked()
{
    this->close();
    MainWindow *fereastraLogare=new MainWindow();
    fereastraLogare->show();
}



void interfataUtilizator::on_butonStergeCont_clicked()
{
    ui->linieText_2->hide();
    ui->linieText->hide();
    ui->dateEdit->hide();
    ui->intrebare->setText("Ștergeți contul?");
    ui->intrebare->show();
    ui->afirmare->show();
    ui->negare->show();
    ui->linieText->setEchoMode(QLineEdit::Normal);
    ui->linieText_2->setEchoMode(QLineEdit::Normal);
}


void interfataUtilizator::on_butonSchimbaNume_clicked()
{
    ui->linieText_2->hide();
    ui->linieText->clear();
    ui->dateEdit->hide();
    ui->intrebare->setText("Introduceți noul nume");
    ui->intrebare->show();
    ui->afirmare->show();
    ui->negare->show();
    ui->linieText->setPlaceholderText("Noul nume");
    ui->linieText->show();
    ui->linieText->setEchoMode(QLineEdit::Normal);
    ui->linieText_2->setEchoMode(QLineEdit::Normal);
}


void interfataUtilizator::on_negare_clicked()
{
    ui->linieText->clear();
    ui->afirmare->hide();
    ui->intrebare->hide();
    ui->negare->hide();
    ui->linieText->hide();
    ui->dateEdit->hide();
    ui->linieText_2->hide();
    ui->linieText->setEchoMode(QLineEdit::Normal);
    ui->linieText_2->setEchoMode(QLineEdit::Normal);
}


void interfataUtilizator::on_butonSchimbaPrenume_clicked()
{
        ui->linieText_2->hide();
    ui->linieText->clear();
    ui->dateEdit->hide();
    ui->intrebare->setText("Introduceți noul prenume");
        ui->intrebare->show();
    ui->afirmare->show();
    ui->negare->show();
    ui->linieText->setPlaceholderText("Noul prenume");
    ui->linieText->show();
    ui->linieText->setEchoMode(QLineEdit::Normal);
    ui->linieText_2->setEchoMode(QLineEdit::Normal);

}


void interfataUtilizator::on_butonSchimbaDataNastere_clicked()
{
        ui->linieText_2->hide();
    ui->linieText->hide();
    ui->intrebare->setText("Introduceți data nasterii");
        ui->intrebare->show();
    ui->afirmare->show();
    ui->negare->show();
    ui->dateEdit->show();
    ui->linieText->setEchoMode(QLineEdit::Normal);
    ui->linieText_2->setEchoMode(QLineEdit::Normal);
}


void interfataUtilizator::on_afirmare_clicked()
{
    if(ui->intrebare->text()=="Introduceți data nasterii")
    {
        //qDebug()<<"Protocol schimbare data nasterii";
        QString changeBirthdate;
        changeBirthdate.clear();
        changeBirthdate="8`"+this->userName+"`"+
                          QString::number(ui->dateEdit->date().day())+"`"+
                          QString::number(ui->dateEdit->date().month())+"`"+
                          QString::number(ui->dateEdit->date().year())+"`";
        //Pentru protocolul de logare vom folosii prefixul 8
        //qDebug()<<changeBirthdate;

        QByteArray byteArray=changeBirthdate.toUtf8();

        char* ProtChangeBirthdate=byteArray.data();
        QString c;
        if (conexiune.checkConnection()) {
           c=this->conexiune.connectServer(ProtChangeBirthdate);
        }
        else
        {
           c="eroare";
        }



    }
    if(ui->intrebare->text()=="Introduceți noul prenume")
    {
        this->prenume=ui->linieText->text();
        ui->afisareNume->setText(this->nume+" "+this->prenume);
        QString changeName;
        changeName.clear();
        changeName="6`"+this->userName+"`"+ui->linieText->text()+"`";
        //Pentru protocolul de logare vom folosii prefixul 1
        //qDebug()<<changeName;

        QByteArray byteArray=changeName.toUtf8();

        char* ProtChangeName=byteArray.data();

        QString d;
        if (conexiune.checkConnection()) {
           d=this->conexiune.connectServer(ProtChangeName);
        }
        else
        {
           d="eroare";
        }

    }
    if(ui->intrebare->text()=="Introduceți noul nume")
    {
        this->nume=ui->linieText->text();
        ui->afisareNume->setText(this->nume+" "+this->prenume);
        QString changePrename;
        changePrename.clear();
        changePrename="7`"+this->userName+"`"+ui->linieText->text()+"`";
        //Pentru protocolul de logare vom folosii prefixul 1
        //qDebug()<<changePrename;

        QByteArray byteArray=changePrename.toUtf8();

        char* ProtChangePrenume=byteArray.data();
        QString d;
        if (conexiune.checkConnection()) {
           d=this->conexiune.connectServer(ProtChangePrenume);
        }
        else
        {
           d="eroare";
        }
    }
    if(ui->intrebare->text()=="Ștergeți contul?")
    {
        QString deleteCount;
        deleteCount.clear();
        deleteCount="9`"+this->userName+"`";
        //Pentru protocolul de logare vom folosii prefixul 1
        //qDebug()<<deleteCount;

        QByteArray byteArray=deleteCount.toUtf8();

        char* ProtDeleteCont=byteArray.data();
        QString d;
        if (conexiune.checkConnection()) {
           d=this->conexiune.connectServer(ProtDeleteCont);
        }
        else
        {
           d="eroare";
        }

        this->close();
        MainWindow *fereastraLogare=new MainWindow();
        fereastraLogare->show();
    }
    if(ui->intrebare->text()=="Schimbă parola")
    {

        if(ui->linieText->text()==ui->linieText_2->text() and ui->linieText->text().length()>0)
        {
           QString mesajPrimit=protocol.protocolA(this->userName,ui->linieText->text());
        }


    }
    ui->afirmare->hide();
    ui->intrebare->hide();
    ui->negare->hide();
    ui->linieText->hide();
    ui->dateEdit->hide();
    ui->linieText->clear();
    ui->linieText_2->hide();
    ui->linieText->setEchoMode(QLineEdit::Normal);
    ui->linieText_2->setEchoMode(QLineEdit::Normal);
}


void interfataUtilizator::on_negCreare_clicked()
{
    this->actualizeazaSalvari();


    ui->fereastraCreareSolutie->hide();
    ui->camp1venitLunar->clear();
    ui->camp2cheltuieli->clear();
    ui->camp3economii->clear();
    ui->camp4venitPasiv->clear();
    ui->camp5mostenire->clear();
    ui->camp6dobanda->clear();
    ui->camp7durataViata->clear();
    ui->linieText->setEchoMode(QLineEdit::Normal);
    ui->linieText_2->setEchoMode(QLineEdit::Normal);
}


void interfataUtilizator::on_butonCreare_clicked()
{
    this->scrollArea->hide();


    ui->fereastraAfisareSolutie->hide();
    ui->fereastraCreareSolutie->show();
    ui->camp1venitLunar->clear();
    ui->camp2cheltuieli->clear();
    ui->camp3economii->clear();
    ui->camp4venitPasiv->clear();
    ui->camp5mostenire->clear();
    ui->camp6dobanda->clear();
    ui->camp7durataViata->clear();
    ui->camp1venitLunar->show();
    ui->camp2cheltuieli->show();
    ui->camp3economii->show();
    ui->camp4venitPasiv->show();
    ui->camp5mostenire->show();
    ui->camp6dobanda->show();
    ui->camp7durataViata->show();
    ui->negCreare->show();
    ui->accCreare->show();
    ui->descriere1->show();
    ui->descriere1_2->show();
    ui->descriere3->show();
    ui->dobanda->show();
    ui->mostenire->show();
    ui->economii->show();
    ui->optionalIF->show();
    ui->durataViata->show();
    ui->linieText_2->hide();
}


void interfataUtilizator::on_accCreare_clicked()
{

    if(ui->camp1venitLunar->text().length()==0 or ui->camp2cheltuieli->text().length()==0)
    {
        ui->eroare->show();
    }
    else
    {
        if(ui->camp3economii->text().length()==0)
            ui->camp3economii->setText("0");
        if(ui->camp4venitPasiv->text().length()==0)
            ui->camp4venitPasiv->setText("0");
        if(ui->camp5mostenire->text().length()==0)
            ui->camp5mostenire->setText("0");
        if(ui->camp6dobanda->text().length()==0)
            ui->camp6dobanda->setText("6");
        if(ui->camp7durataViata->text().length()==0)
            ui->camp7durataViata->setText("80");

        QString trimitDate,primescDate;
        trimitDate.clear();
        trimitDate="x`"+this->userName+"`"+ui->camp1venitLunar->text()+"`"+ui->camp2cheltuieli->text()+"`"+
            ui->camp3economii->text()+"`"+ui->camp4venitPasiv->text()+"`"+ui->camp5mostenire->text()+"`"+
            ui->camp6dobanda->text()+"`"+ui->camp7durataViata->text()+"`";


        primescDate=protocol.protocolX(trimitDate);
        QStringList parts = primescDate.split('`');


        ui->fereastraCreareSolutie->hide();
        ui->fereastraAfisareSolutie->show();

        this->genereazaGrafic(parts);
        this->genereazaPlacinta(parts);

        QString textSolutie="Vârsta la care vă puteți pensiona este de "+parts[11]+" ani.";
        ui->solutie->setText(textSolutie);
        textSolutie="Aveți nevoie să strângeți în următorii "+parts[13]+" ani "+parts[12]+" de unități monetare.";
        ui->solutie2->setText(textSolutie);
        QString date="Venit: "+parts[3]+", Cheltuieli: "+parts[4]+", Economii: "+parts[5]+", Venituri pasive: "+parts[6]+", Mostenire: "+parts[7]+", Dobanda: "+parts[8];
        ui->date->setText(date);
        ui->salveaza->show();

        ui->aruncaSalvarea->setText("Șterge soluția");
            ui->backCreare->show();
        ui->numeSalvare->show();

    }

}


void interfataUtilizator::on_camp1venitLunar_textEdited(const QString &arg1)
{
    ui->eroare->hide();
}


void interfataUtilizator::on_camp2cheltuieli_textEdited(const QString &arg1)
{
    ui->eroare->hide();
}


void interfataUtilizator::on_butonParola_clicked()
{

    ui->dateEdit->hide();
    ui->linieText->setPlaceholderText("Noua parolă");
    ui->linieText_2->setPlaceholderText("Confirmă noua parolă");
    ui->linieText_2->clear();
    ui->linieText->clear();
    ui->linieText->show();
    ui->linieText_2->show();
    ui->intrebare->setText("Schimbă parola");
    ui->intrebare->show();
    ui->afirmare->show();
    ui->negare->show();
    ui->linieText->setEchoMode(QLineEdit::Password);
    ui->linieText_2->setEchoMode(QLineEdit::Password);

}


void interfataUtilizator::on_pushButton_clicked()
{
    QString sendDate;
    sendDate.clear();

    sendDate="a";
    for(int i=0;i<1000;i++)
        sendDate+="a";

    qDebug()<<sendDate<<" date trimise\n";

    QByteArray byteArray=sendDate.toUtf8();

    char* ProtSendDate=byteArray.data();

    qDebug()<<"exec protocol trimitere date\n";
    this->conexiune.connectServer(ProtSendDate);
    //qDebug()<<x<<" date primite\n";
}


void interfataUtilizator::on_backCreare_clicked()

{
    QString trimitDate,primescDate;
    trimitDate.clear();
    trimitDate="d`"+this->userName+"`NULL`";
    ui->fereastraAfisareSolutie->hide();
    ui->numeSalvare->clear();
    primescDate=protocol.protocolD(trimitDate);
    QStringList parts = primescDate.split('`');
    ui->fereastraAfisareSolutie->hide();

    ui->fereastraCreareSolutie->show();

}



void interfataUtilizator::genereazaGrafic(QStringList parts)

{


    QChart *chart = new QChart;
    QChartView *chartView = new QChartView(chart);
    chartView->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    chartView->setStyleSheet("background-color: rgba(197,242,228,0);");
    QBrush brush(QColor("#f0f0f0"));
    chart->setBackgroundBrush(brush);

    QLineSeries *series = new QLineSeries;
    chart->legend()->setVisible(false);
    qDebug()<<parts[10].toInt();
    qDebug()<<parts[10].toInt();
    int age=parts[10].toInt();
    series->append(age,parts[5].toInt());
    for(int i=14;i<14+parts[13].toInt();i++)
    {
        age++;
        series->append(age,parts[i].toInt());
    }

    chart->addSeries(series);
    QValueAxis *axisX = new QValueAxis;
    QValueAxis *axisY = new QValueAxis;

    axisX->setMin(0);
    axisY->setMin(0);
    axisX->setTitleText("Vârstă");
    axisY->setTitleText("Economii");

    chart->addAxis(axisX, Qt::AlignBottom);
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisX);
    series->attachAxis(axisY);

    QWidget *widget = new QWidget;
    QVBoxLayout *layout = new QVBoxLayout(widget);
    layout->addWidget(chartView);


    QLayout* existingLayout = ui->grafic->layout();
    if (existingLayout) {
        delete existingLayout;
    }
    ui->grafic->setLayout(layout);
}

void interfataUtilizator::genereazaPlacinta(QStringList parts)
{
    int varsta,munca,pensie,viata;
    viata=parts[9].toInt();
    varsta=(100*parts[10].toInt())/viata;
    munca=(100*parts[13].toInt())/viata;
    pensie=100-varsta-munca;

    QWidget *widget2 = new QWidget;
    QVBoxLayout *layout2 = new QVBoxLayout(widget2);
    QChart *chart2 = new QChart;
    QChartView *chartView2 = new QChartView(chart2);
    chartView2->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    chartView2->setStyleSheet("background-color: rgba(197,242,228,0);");
    QBrush brush(QColor("#C9F2E3"));
    chart2->setBackgroundBrush(brush);
    chart2->legend()->setVisible(true);
    QPieSeries *series2 = new QPieSeries;
    series2->append("Varsta", varsta);
    series2->append("Activitate", munca);
    series2->append("Pensie", pensie);

    series2->setPieSize(0.9);
    chart2->addSeries(series2);
    layout2->addWidget(chartView2);

    QLayout* existingLayout = ui->placinta->layout();
    if (existingLayout) {
        delete existingLayout;
    }
    ui->placinta->setLayout(layout2);
    ui->placinta->show();
}

void interfataUtilizator::on_salveaza_clicked()
{
    if(ui->numeSalvare->text().length()>0)
    {
    QString trimitDate,primescDate;
    trimitDate.clear();
    trimitDate="s`"+this->userName+"`"+ui->numeSalvare->text()+"`";
    ui->fereastraAfisareSolutie->hide();
    ui->numeSalvare->clear();
    primescDate=protocol.protocolS(trimitDate);
    QStringList parts = primescDate.split('`');
    if(parts[1]!=this->userName)
        primescDate="eroare";
    qDebug()<<primescDate;

    //apelam fereastra salvari
    this->actualizeazaSalvari();
    }
}


void interfataUtilizator::on_aruncaSalvarea_clicked()

{
    //apelam protocol stergere salvare
    this->actualizeazaSalvari();

    QString trimitDate,primescDate;
    trimitDate.clear();
    trimitDate="d`"+this->userName+"`NULL`";
    ui->fereastraAfisareSolutie->hide();
    ui->numeSalvare->clear();
    primescDate=protocol.protocolD(trimitDate);
    QStringList parts = primescDate.split('`');

    ui->fereastraAfisareSolutie->hide();
}

void interfataUtilizator::actualizeazaSalvari()
{


    scrollArea = new QScrollArea(this);
    scrollArea->setGeometry(210,170,785,495);
    scrollArea->setStyleSheet("background-color: transparent;");

    scrollableContent = new QWidget(scrollArea);
    layout = new QVBoxLayout(scrollableContent);


    QString cadruPrimit=protocol.protocolG(this->userName);
    QStringList parts = cadruPrimit.split('`');

    int numButoane=parts[2].toInt();

    for (int i = 0; i < numButoane; ++i) {
    QHBoxLayout *rowLayout = new QHBoxLayout();
    QString ceAfisez="Numele salvării: "+parts[3+i*4]+", data salvării: "+parts[6+i*4]+"-"+parts[5+i*4]+"-"+parts[4+i*4];
    salvari.push_back(parts[3+i*4]);

    QLabel* label = new QLabel(ceAfisez, scrollableContent);
    QPushButton* button1 = new QPushButton("Șterge", scrollableContent);
    QPushButton* button2 = new QPushButton("Vezi", scrollableContent);

    label->setFixedSize(400, 45);
    label->setStyleSheet("color: white; background-color:#8AA69B;"
                         " border-radius: 4px;font-size: 14px; padding: 10px 20px;font-weight: bold;");

    button1->setFixedSize(100,45);
    button1->setStyleSheet("QPushButton {background-color: #4285F4; color: white;border: none;border-radius: 4px;padding: 10px 20px;font-size: 14px;font-weight: bold;}"
            "QPushButton:hover {background-color: #3367D6;}"
            "QPushButton:pressed {background-color: #254EDA;}");
    button2->setFixedSize(100,45);
    button2->setStyleSheet("QPushButton {background-color: #4285F4; color: white;border: none;border-radius: 4px;padding: 10px 20px;font-size: 14px;font-weight: bold;}"
                           "QPushButton:hover {background-color: #3367D6;}"
                           "QPushButton:pressed {background-color: #254EDA;}");

    rowLayout->addWidget(label);
    rowLayout->addWidget(button1);
    rowLayout->addWidget(button2);



    layout->addLayout(rowLayout);

    labels.push_back(label);
    buttons1.push_back(button1);
    buttons2.push_back(button2);
    }



    scrollArea->setWidget(scrollableContent);

    for (int row = 0; row < buttons2.size(); ++row) {
    connect(buttons2[row], &QPushButton::clicked, [this, row]() {buton2salvari(row);});
    }
    for (int row = 0; row < buttons1.size(); ++row) {
    connect(buttons1[row], &QPushButton::clicked, [this, row]() {buton1salvari(row);});
    }
    scrollableContent->show();
    scrollArea->show();
}


void interfataUtilizator::buton2salvari(int row)
{
    this->scrollableContent->hide();
    this->scrollArea->hide();

    if(ui->camp3economii->text().length()==0)
    ui->camp3economii->setText("0");
    if(ui->camp4venitPasiv->text().length()==0)
    ui->camp4venitPasiv->setText("0");
    if(ui->camp5mostenire->text().length()==0)
    ui->camp5mostenire->setText("0");
    if(ui->camp6dobanda->text().length()==0)
    ui->camp6dobanda->setText("6");
    if(ui->camp7durataViata->text().length()==0)
    ui->camp7durataViata->setText("80");

    QString primescDate=protocol.protocolg(this->userName,salvari[row]);

    QStringList parts = primescDate.split('`');


    ui->fereastraCreareSolutie->hide();
    ui->fereastraAfisareSolutie->show();

    this->genereazaGrafic(parts);
    this->genereazaPlacinta(parts);

    QString textSolutie="Vârsta la care vă puteți pensiona este de "+parts[11]+" ani.";
    ui->solutie->setText(textSolutie);
    textSolutie="Aveți nevoie să strângeți în următorii "+parts[13]+" ani "+parts[12]+" de unități monetare.";
    ui->solutie2->setText(textSolutie);
    QString date="Venit: "+parts[3]+", Cheltuieli: "+parts[4]+", Economii: "+parts[5]+", Venituri pasive: "+parts[6]+", Mostenire: "+parts[7]+", Dobanda: "+parts[8];
    ui->date->setText(date);

    ui->salveaza->hide();
    ui->aruncaSalvarea->setText("Înapoi");
        ui->backCreare->hide();
    ui->numeSalvare->hide();
}

void interfataUtilizator::buton1salvari(int row)
{
    QString mesajTrimis="d`"+this->userName+"`"+salvari[row]+"`";
    QString mesajPrimit=protocol.protocolD(mesajTrimis);
    this->scrollArea->hide();
    this->actualizeazaSalvari();

}

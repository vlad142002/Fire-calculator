
#include "mainwindow.h"

#include <QApplication>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setMinimumSize(1000,667);
    w.setMaximumSize(1000,667);
    w.setWindowTitle("Fire Calculator App");

    w.show();
    return a.exec();
}


#ifndef PROTOCOALE_H
#define PROTOCOALE_H
#include<qstring>
#include"conectare.h"


class protocoale
{
public:
    protocoale();

    QString protocolX(QString cadru);
    QString protocolS(QString cadru);
    QString protocolD(QString cadru);
    QString protocolG(QString user);
    QString protocol4(QString user);
    QString protocol1(QString user,QString parola);
    QString protocol2(QString user);
    QString protocolg(QString user,QString save);
    QString protocolA(QString user,QString parola);
    QString protocol9(QString user);
    QString protocolU();


private:
    conectare conect;


};

#endif // PROTOCOALE_H

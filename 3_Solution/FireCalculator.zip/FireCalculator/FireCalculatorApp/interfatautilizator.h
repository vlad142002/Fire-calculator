#ifndef INTERFATAUTILIZATOR_H
#define INTERFATAUTILIZATOR_H

#include <QDialog>
#include<QVBoxLayout>
#include<QToolButton>
#include<QDate>
#include <QFont>
#include <QDateTime>
#include <QLabel>
#include <QTimer>
#include"conectare.h"
#include"protocoale.h"
#include"QScrollArea"

namespace Ui {
class interfataUtilizator;
}

class interfataUtilizator : public QDialog
{
    Q_OBJECT

public:
    explicit interfataUtilizator(QString user,QWidget *parent = nullptr);
    ~interfataUtilizator();

private slots:
    void on_butonExit_clicked();




    void on_butonStergeCont_clicked();

    void on_butonSchimbaNume_clicked();

    void on_negare_clicked();

    void on_butonSchimbaPrenume_clicked();

    void on_butonSchimbaDataNastere_clicked();

    void on_afirmare_clicked();

    void on_negCreare_clicked();

    void on_butonCreare_clicked();

    void on_accCreare_clicked();

    void on_camp1venitLunar_textEdited(const QString &arg1);

    void on_camp2cheltuieli_textEdited(const QString &arg1);

    void on_butonParola_clicked();

    void on_pushButton_clicked();

    void on_backCreare_clicked();

    void genereazaGrafic(QStringList parts);

    void genereazaPlacinta(QStringList parts);

    void on_salveaza_clicked();

    void on_aruncaSalvarea_clicked();

    void actualizeazaSalvari();


private slots:
    void buton2salvari(int row);
    void buton1salvari(int row);

private:
    QString userName;
    QString nume,prenume;
    QDate dataNasterii;
    QScrollArea* scrollArea;
    QWidget* scrollableContent;

    QVBoxLayout* layout;
    std::vector<QLabel*> labels;
    std::vector<QPushButton*> buttons1;
    std::vector<QPushButton*> buttons2;
    std::vector<QString> salvari;

    Ui::interfataUtilizator *ui;
    //QVBoxLayout* layout;
   // QList <QToolButton*> buttonList;
    conectare conexiune;
    protocoale protocol;
};

#endif // INTERFATAUTILIZATOR_H

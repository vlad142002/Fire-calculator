#include "crearec.h"
#include "ui_crearec.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "conectare.h"
#include"interfatautilizator.h"
#include"ui_interfatautilizator.h"

creareC::creareC(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::creareC)
{
    ui->setupUi(this);
    this->setMaximumSize(1000,667);
    this->setMinimumSize(1000,667);

    ui->labelData->setAttribute(Qt::WA_TranslucentBackground);
    ui->eroareConfirmareParola->setAttribute(Qt::WA_TranslucentBackground);
    ui->eroareConfirmareParola->hide();
    ui->checkUserNameCreare->setAttribute(Qt::WA_TranslucentBackground);
    ui->checkUserNameCreare->hide();
    ui->checkNume->setAttribute(Qt::WA_TranslucentBackground);
    ui->checkPrenume->setAttribute(Qt::WA_TranslucentBackground);
    ui->checkPrenume->hide();
    ui->checkNume->hide();

}

creareC::~creareC()
{
    delete ui;
}


void creareC::on_creareParola_2_textChanged(const QString &arg1)
{
    if(ui->creareParola->text()==ui->creareParola_2->text())
    {
        if(ui->creareParola->text().length()<4)
        {
            ui->eroareConfirmareParola->setText("<font color=#EC9F05>Parola minim 4 caractere</font>");
            ui->eroareConfirmareParola->show();
        }
        else
        {
        ui->eroareConfirmareParola->setText("<font color=#256D1B>Parole OK</font>");
        ui->eroareConfirmareParola->show();
        }
    }
    else
    {
        ui->eroareConfirmareParola->setText("<font color=#aa0000>Eroare: parolele nu coincid!</font>");
        ui->eroareConfirmareParola->show();
    }

}

void creareC::on_butonCreareCont_clicked()
{
    int ok=1;
    if(ui->creareParola->text()==ui->creareParola_2->text())
    {
        ui->eroareConfirmareParola->setText("<font color=#256D1B>Parole OK</font>");
        ui->eroareConfirmareParola->show();
        ok=1;
    }
    else
    {
        ui->eroareConfirmareParola->setText("<font color=#aa0000>Eroare: parolele nu coincid!</font>");
        ui->eroareConfirmareParola->show();
        ok=0;
    }
    if(ui->creareParola->text().length()<4)
    {
        ui->eroareConfirmareParola->setText("<font color=#EC9F05>Parola minim 4 caractere</font>");
        ui->eroareConfirmareParola->show();
        ok=0;
    }

    if(ui->creareNume->text().length()==0)
    {
        ui->checkNume->setText("<font color=#aa0000>Eroare: introdu nume!</font>");
        ui->checkNume->show();
        ok=0;
    }

    if(ui->crearePrenume->text().length()==0)
    {
        ui->checkPrenume->setText("<font color=#aa0000>Eroare: introdu prenume!</font>");
        ui->checkPrenume->show();
        ok=0;
    }
    //qDebug()<<ok;
    if(ok)
    {

    QString checkUser;
    checkUser.clear();
    checkUser="2`"+ui->creareUserName->text()+"`";
    //Pentru protocolul de check user vom folosii prefixul 2

    QByteArray byteArray=checkUser.toUtf8();

    char* ProtUser=byteArray.data();
    QString b=conexiune.connectServer(ProtUser);

    QStringList parts = b.split('`');
    if(parts[0]=="2" && parts[1]==ui->creareUserName->text() && parts[2]=="0")
    {
        QString sendDate;
        sendDate.clear();
        sendDate="3`"+ui->creareUserName->text()+"`"+ui->creareNume->text()+"`"+ui->crearePrenume->text()+"`"+QString::number(ui->dateEdit->date().day())+"`"+QString::number(ui->dateEdit->date().month())+"`"+QString::number(ui->dateEdit->date().year())+"`"+ui->creareParola->text()+"`";
        //qDebug()<<sendDate;
        QByteArray byteArray2=sendDate.toUtf8();
        char* ProtInsert=byteArray2.data();
        qDebug()<<ProtInsert<<"prot inserare ce am trimis";
        QString c=conexiune.connectServer(ProtInsert);
        qDebug()<<c<<"prot inserare ce primesc";
        QStringList parts2 = c.split('`');
        //qDebug()<<c<<"\n";

        if(parts2[0]=="3" && parts2[1]==ui->creareUserName->text() && parts2[2]=="1")
        {
        this->close();
        interfataUtilizator *user=new interfataUtilizator(ui->creareUserName->text());
        user->show();
        }
        else
        {
        qDebug()<<"eroare la inserare";
        }
    }
    else
        ui->checkUserNameCreare->show();

    }
}



void creareC::on_buton_inapoi_clicked()
{
    this->close();
    MainWindow *fereastraLogare=new MainWindow();
    fereastraLogare->show();
}




void creareC::on_creareNume_textEdited(const QString &arg1)
{
    ui->checkNume->hide();
}


void creareC::on_crearePrenume_textEdited(const QString &arg1)
{
    ui->checkPrenume->hide();
}


void creareC::on_creareUserName_textEdited(const QString &arg1)
{
    ui->checkUserNameCreare->hide();
}



#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "crearec.h"
#include "ui_crearec.h"
#include "interfatautilizator.h"
#include "ui_interfatautilizator.h"
#include "admin.h"
#include "ui_admin.h"
#include "conectare.h"
#include<QDebug>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    this->setMaximumSize(1000,667);
    this->setMinimumSize(1000,667);

    ui->campUserName->setPlaceholderText("Nume utilizator");
    ui->campParola->setPlaceholderText("Parola");
    ui->BunVenit->setAttribute(Qt::WA_TranslucentBackground);
    ui->BunVenit_2->setAttribute(Qt::WA_TranslucentBackground);
    ui->eroareLogare->setAttribute(Qt::WA_TranslucentBackground);
    ui->eroareLogare->hide();
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_butonLogare_clicked()
{
    if(ui->campUserName->text().length()==0 or ui->campParola->text().length()==0)
    {
        ui->eroareLogare->show();
        return;
    }

    if(ui->campUserName->text()=="2" and ui->campParola->text()=="2")
    {
        this->close();
        this->hide();
        Admin *user=new Admin();
        user->show();
    }

    if(ui->campUserName->text()=="1" and ui->campParola->text()=="1")
    {
        //COD PENTRU A INTRA PE INTERFATA DE ADMINthis->hide();

        this->hide();
        this->close();
        this->hide();
        interfataUtilizator *user=new interfataUtilizator(ui->campUserName->text());
        user->show();
    }
    else
    {

    QString mesajPrimit=prot.protocol1(ui->campUserName->text(),ui->campParola->text());


    QStringList parts =mesajPrimit.split('`');
    if(parts[1]==ui->campUserName->text() and parts[2]=='1')
    {
        //s
        this->close();
        this->hide();
        interfataUtilizator *user=new interfataUtilizator(ui->campUserName->text());
        user->show();
    }
    else
    {if(parts[1]==ui->campUserName->text() and parts[2]=='2')
        {
        this->close();
        this->hide();
        Admin *user=new Admin();
        user->show();
        }
        else
        {ui->eroareLogare->show();}
    }}

}


void MainWindow::on_campUserName_textChanged(const QString &arg1)
{
    ui->eroareLogare->hide();
}


void MainWindow::on_campParola_textChanged(const QString &arg1)
{
    ui->eroareLogare->hide();
}


void MainWindow::on_butonCreareCont_clicked()
{
    this->close();
    this->hide();
    creareC *fereastraCreareCont= new creareC();
    fereastraCreareCont->show();
}


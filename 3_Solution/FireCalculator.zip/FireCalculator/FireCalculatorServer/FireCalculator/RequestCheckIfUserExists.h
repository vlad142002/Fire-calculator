#pragma once
#include "Request.h"
class RequestCheckIfUserExists :
    public Request
{
public:
    RequestCheckIfUserExists(){}
    ~RequestCheckIfUserExists(){}

    virtual char* execute(vector<char*> v) override
    {
        strcpy(buffer, Database::getInstance().checkIfUserExists(v[1]));

        return buffer;
    }
};
#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <string>
#include <mysql.h>

using namespace std;

class Database
{
private:
	static Database* instance;
	MYSQL* conn;
	MYSQL_ROW row;
	MYSQL_RES* res;
	char* buffer;
	Database();
	~Database();
	Database(const Database&){}
public:
	static Database& getInstance();
	void destroyInstance();

	char* checkIfUserAndPasswordMatch(char* u, char* p);
	char* checkIfUserExists(char* u);
	char* insert(char* u, char* l, char* f, char* d, char* m, char* y, char* p);
	char* getData(char* u);
	int getUserAge(string u);
	int getUserId(string u);
	int getLastId(string table);
	char* generateResult(char* u, char* mi, char* me, char* s, char* pi, char* l, char* wr,
	char* ma);
	char* save(char* u, char* n);
	char* Delete(char* u, char* n);
	char* getResults(char* u);
	char* changeFirstName(char* u, char* fn);
	char* changeLastName(char* u, char* ln);
	char* changeBirthdate(char* u, char* d, char* m, char* y);
	char* changePassword(char* u, char* p);
	char* DeleteAccount(char* u);
	char* getSavedResult(char* u, char* n);
	char* getRequests();
	char* getUsers();
};
#pragma once
#include"Database.h"
#include "IAdminResponse.h"
class AdminResponse :
    public IAdminResponse
{
protected:
    char* buffer;
public:
    AdminResponse(){ buffer = new char[1024]; }
    ~AdminResponse() { delete buffer; }
};


#pragma once
__interface IAdminResponse
{
public:
	virtual char* execute() = 0;
};

namespace FactoryAdmin
{
	enum class Response{getRequest, getUsers};
	static IAdminResponse* factoryAdminStaticMethod(Response r);
}
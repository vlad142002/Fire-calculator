#pragma once
#include "Request.h"
class RequestChangePassword :
    public Request
{
public:
    RequestChangePassword(){}
    ~RequestChangePassword(){}

    virtual char* execute(vector<char*> v) override
    {
        strcpy(buffer, Database::getInstance().changePassword(v[1], v[2]));
        
        return buffer;
    }
};


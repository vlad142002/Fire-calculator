#pragma once
#include "Request.h"
class RequestDeleteAccount :
    public Request
{
    public:
    RequestDeleteAccount(){}
    ~RequestDeleteAccount(){}

    virtual char* execute(vector<char*> v) override
    {
        strcpy(buffer, Database::getInstance().DeleteAccount(v[1]));
        
        return buffer;
    }
};


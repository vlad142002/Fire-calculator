#pragma once
#include "IRequest.h"
class RequestGetResult :
    public IRequest
{
public:

};


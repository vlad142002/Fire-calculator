#pragma once
#include "IRequest.h"
class Request :
    public IRequest
{
protected:
    char* buffer;

public:
    Request() { buffer = new char[1024]; }
    ~Request() { delete buffer; }
};


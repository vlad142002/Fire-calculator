#pragma once
#include "Request.h"
class RequestChangeLastName :
    public Request
{
public:
    RequestChangeLastName(){}
    ~RequestChangeLastName(){}

    virtual char* execute(vector<char*> v) override
    {
        strcpy(buffer, Database::getInstance().changeLastName(v[1], v[2]));
        
        return buffer;
    }
};


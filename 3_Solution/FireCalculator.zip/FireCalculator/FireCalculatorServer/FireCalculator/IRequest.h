#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include"Database.h"
__interface IRequest
{
public:
	virtual char* execute(vector<char*> v) = 0;
};

namespace Factory
{
	enum class Request {changeBirthdate, changeFirstName, changeLastName, changePassword, 
		checkIfUserExists, checkUsernameAndPassword, createAccount, deleteAccount, deleteResult,
	generateResult, getResults, getUserData, savedResult, saveResult};
	static IRequest* factoryStaticMethod(Request r);
}
#pragma once
#include "Request.h"
class RequestCheckUsernameAndPassword :
    public Request
{
public:
    RequestCheckUsernameAndPassword(){}
    ~RequestCheckUsernameAndPassword(){}

    virtual char* execute(vector<char*> v) override
    {
        strcpy(buffer, Database::getInstance().checkIfUserAndPasswordMatch(v[1], v[2]));
        
        return buffer;
    }
};


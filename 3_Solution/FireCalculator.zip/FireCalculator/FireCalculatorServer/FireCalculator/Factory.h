#pragma once
#include "IRequest.h"
#include "RequestCreateAccount.h"
#include"RequestChangeBirthdate.h"
#include"RequestChangeFirstName.h"
#include"RequestChangeLastName.h"
#include"RequestChangePassword.h"
#include "RequestCheckIfUserExists.h"
#include "RequestCheckUsernameAndPassword.h"
#include"RequestCreateAccount.h"
#include"RequestDeleteAccount.h"
#include "RequestDeleteResult.h"
#include "RequestGetResults.h"
#include "RequestGetUserData.h"
#include "RequestGenerateResult.h"
#include"RequestSavedResult.h"
#include "RequestSaveResult.h"


namespace Factory
{
	static IRequest* Factory::factoryStaticMethod(Factory::Request r)
	{
		switch (r)
		{
		case Factory::Request::changeBirthdate:
			return new RequestChangeBirthdate;
			break;
		case Factory::Request::changeFirstName:
			return new RequestChangeFirstName;
			break;
		case Factory::Request::changeLastName:
			return new RequestChangeLastName;
			break;
		case Factory::Request::changePassword:
			return new RequestChangePassword;
			break;
		case Factory::Request::checkIfUserExists:
			return new RequestCheckIfUserExists;
			break;
		case Factory::Request::checkUsernameAndPassword:
			return new RequestCheckUsernameAndPassword;
			break;
		case Factory::Request::createAccount:
			return new RequestCreateAccount;
			break;
		case Factory::Request::deleteAccount:
			return new RequestDeleteAccount;
			break;
		case Factory::Request::deleteResult:
			return new RequestDeleteResult;
			break;
		case Factory::Request::generateResult:
			return new RequestGenerateResult;
			break;
		case Factory::Request::getResults:
			return new RequestGetResults;
			break;
		case Factory::Request::getUserData:
			return new RequestGetUserData;
			break;
		case Factory::Request::saveResult:
			return new RequestSaveResult;
			break;
		case Factory::Request::savedResult:
			return new RequestSavedResult;
			break;
		}
	}
}
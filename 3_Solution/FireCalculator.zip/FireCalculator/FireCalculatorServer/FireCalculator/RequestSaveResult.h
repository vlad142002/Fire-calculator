#pragma once
#include "Request.h"
class RequestSaveResult :
    public Request
{
public:
    RequestSaveResult(){}
    ~RequestSaveResult(){}

    virtual char* execute(vector<char*> v) override
    {
        strcpy(buffer, Database::getInstance().save(v[1], v[2]));
        
        return buffer;
    }
};
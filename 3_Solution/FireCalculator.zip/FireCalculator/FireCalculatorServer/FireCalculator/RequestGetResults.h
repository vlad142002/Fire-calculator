#pragma once
#include "Request.h"
class RequestGetResults :
    public Request
{
public:
    RequestGetResults(){}
    ~RequestGetResults(){}

    virtual char* execute(vector<char*> v) override
    {
        cout << "sec1" << endl;
        strcpy(buffer, Database::getInstance().getResults(v[1]));
        cout << "sec2" << endl;

        return buffer;
    }
};
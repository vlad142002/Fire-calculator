#pragma once
#include "AdminResponse.h"
class AdminGetUsers :
    public AdminResponse
{
public:
    AdminGetUsers(){}
    ~AdminGetUsers(){}

    virtual char* execute() override
    {
        strcpy(buffer, Database::getInstance().getUsers());

        return buffer;
    }
};

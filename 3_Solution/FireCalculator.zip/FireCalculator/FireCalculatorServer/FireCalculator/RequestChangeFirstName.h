#pragma once
#include "Request.h"
class RequestChangeFirstName :
    public Request
{
    public:
    RequestChangeFirstName() {}
    ~RequestChangeFirstName() {}

    virtual char* execute(vector<char*> v) override
    {
        strcpy(buffer, Database::getInstance().changeFirstName(v[1], v[2]));
    
        return buffer;
    }
};


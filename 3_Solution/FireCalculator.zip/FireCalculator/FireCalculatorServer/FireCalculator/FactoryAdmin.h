#include"AdminGetRequests.h"
#include"AdminGetUsers.h"

namespace FactoryAdmin
{
	static IAdminResponse* FactoryAdmin::factoryAdminStaticMethod(FactoryAdmin::Response r)
	{
		switch (r)
		{
		case FactoryAdmin::Response::getRequest:
				return new AdminGetRequests();
				break;
		case FactoryAdmin::Response::getUsers:
			return new AdminGetUsers();
			break;
		}
	}
}
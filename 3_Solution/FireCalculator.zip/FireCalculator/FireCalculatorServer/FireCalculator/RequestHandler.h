#pragma once
#include"Database.h"
#include"IRequest.h"
#include"IAdminResponse.h"
#include"Factory.h"
#include"FactoryAdmin.h"
#include <vector>

using namespace std;

class RequestHandler
{
private:
	vector<char*>parameters;
	char* token;
public:
	RequestHandler()
	{
		token = NULL;
	}
	~RequestHandler() 
	{
		parameters.clear(); 
	}

	char* chooseRequest(char* r);
};
#pragma once
#include "Request.h"
class RequestGetUserData :
    public Request
{
public:
    RequestGetUserData(){}
    ~RequestGetUserData(){}

    virtual char* execute(vector<char*> v) override
    {
        strcpy(buffer, Database::getInstance().getData(v[1]));
        
        return buffer;
    }
};
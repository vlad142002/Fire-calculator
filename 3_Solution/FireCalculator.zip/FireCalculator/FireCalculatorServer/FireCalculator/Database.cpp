#include "Database.h"

Database* Database::instance = nullptr;

Database& Database::getInstance()
{
	if (!Database::instance)
	{
		Database::instance = new Database();
	}

	return(*Database::instance);
}

void Database::destroyInstance()
{
	if (Database::instance)
	{
		delete Database::instance;
		Database::instance = nullptr;
	}
}

Database::Database()
{
	conn = mysql_init(0);
	row = nullptr;
	res = nullptr;
	buffer = new char[2048];
	mysql_real_connect(conn, "localhost", "root", "parola", "firecalculator",
		3306, NULL, 0);
}

Database::~Database()
{
	conn = nullptr;
	row=nullptr;
	res=nullptr;
	delete buffer;
}

char* Database::checkIfUserAndPasswordMatch(char* u, char* p)
{
	string stru(u);
	string strp(p);
	string query = "SELECT * FROM users WHERE username='" + stru + "' AND password='"
		+ strp + "';";

	strcpy(buffer, "1`");
	strcat(buffer, u);
	strcat(buffer, "`");
	strcat(buffer, "1");
	strcat(buffer, "`");
	strcat(buffer, "");
	mysql_query(conn, query.c_str());
	res = mysql_store_result(conn);
	row= mysql_fetch_row(res);
	if (mysql_num_rows(res) < 1)
	{
		buffer[strlen(buffer) - 2] = '0';
		strcat(buffer, "");
	}
	else if (strcmp(row[1],"admin")==0 && strcmp(row[2],"admin")==0)
	{
		buffer[strlen(buffer) - 2] = '2';
		strcat(buffer, "");
	}

	stru.clear();
	strp.clear();
	query.clear();

	mysql_free_result(res);
	return buffer;
}

char* Database::checkIfUserExists(char* u)
{
	string stru(u);
	string query = "SELECT * FROM users WHERE username='" + stru + "';";

	strcpy(buffer, "2`");
	strcat(buffer, u);
	strcat(buffer, "`");
	strcat(buffer, "0");
	strcat(buffer, "`");
	strcat(buffer, "");
	mysql_query(conn, query.c_str());
	res = mysql_store_result(conn);
	if (mysql_num_rows(res) > 0)
	{
		buffer[strlen(buffer) - 2] = '1';
		strcat(buffer, "");
	}

	stru.clear();
	query.clear();

	mysql_free_result(res);

	return buffer;
}

char* Database::insert(char* u, char* l, char* f, char* d, char* m, char* y, char* p)
{
	strcpy(buffer, "3`");
	strcat(buffer, u);
	strcat(buffer, "`1`");
	strcat(buffer, "");
	string stry(y);
	string strm(m);
	string strd(d);
	string stdu(u);
	string stdl(l);
	string stdf(f);
	string stdp(p);
	string birthdate = stry + '-' + strm + '-' + strd;

	string query = "INSERT INTO users(id, username, lastname, firstname, birthdate, password) VALUES("
		+ to_string(getLastId("users")) + ", '" + stdu + "', '" + stdl + "', '" + stdf + "', '"
		+ birthdate + "', '" + stdp + "');";

	if (mysql_query(conn, query.c_str()) != 0)
	{
		buffer[strlen(buffer) - 2] = '0';
		strcat(buffer, "");
	}

	stry.clear();
	strm.clear();
	strd.clear();
	stdu.clear();
	stdl.clear();
	stdf.clear();
	stdp.clear();
	birthdate.clear();
	query.clear();

	return buffer;
}

char* Database::getData(char* u)
{
	strcpy(buffer, "4`");
	strcat(buffer, u);
	strcat(buffer, "`");

	string stru(u);

	string query = "SELECT lastname, firstname, birthdate FROM users WHERE username='"
		+ stru + "';";

	if (mysql_query(conn, query.c_str()) == 0)
	{
		res = mysql_store_result(conn);
		row = mysql_fetch_row(res);

		strcat(buffer, row[0]);
		strcat(buffer, "`");
		strcat(buffer, row[1]);
		strcat(buffer, "`");

		char* token = new char[strlen(row[2])];
		strcpy(token, "");
		strcat(token, row[2]);

		char* tokken = strtok(token, "-");
		while (tokken)
		{
			strcat(buffer, tokken);
			strcat(buffer, "`");
			tokken = strtok(NULL, "-");
		}
	}

	stru.clear();
	query.clear();

	mysql_free_result(res);

	return buffer;
}

int Database::getUserAge(string u)
{
	int age = 0;
	string query = "SELECT cast(DATEDIFF(sysdate(), birthdate)/365 as decimal) FROM users WHERE username='"
		+ u + "';";
	if (mysql_query(conn, query.c_str()) == 0)
	{
		res = mysql_store_result(conn);
		row = mysql_fetch_row(res);
		age = atoi(row[0]);
	}

	query.clear();

	mysql_free_result(res);

	return age;
}

int Database::getUserId(string u)
{
	int id = 0;
	string query = "SELECT id FROM users WHERE username='" + u + "';";
	if (mysql_query(conn, query.c_str()) == 0)
	{
		res = mysql_store_result(conn);
		row = mysql_fetch_row(res);
		id = atoi(row[0]);
	}

	query.clear();

	mysql_free_result(res);

	return id;
}

int Database::getLastId(string table)
{
	int id = 0;
	string query = "SELECT MAX(id) FROM " + table + ";";

	if (mysql_query(conn, query.c_str()) == 0)
	{
		res = mysql_store_result(conn);
		row = mysql_fetch_row(res);
		id = atoi(row[0]);
	}

	id++;

	query.clear();

	mysql_free_result(res);

	return id;
}

char* Database::generateResult(char* u, char* mi, char* me, char* s, char* pi, char* l, char* wr,
	char* ma)
{
	strcpy(buffer, "x`");
	strcat(buffer, u);
	strcat(buffer, "");
	strcat(buffer, "`");
	strcat(buffer, "1`");
	strcat(buffer, mi);
	strcat(buffer, "");
	strcat(buffer, "`");
	strcat(buffer, me);
	strcat(buffer, "");
	strcat(buffer, "`");
	strcat(buffer, s);
	strcat(buffer, "");
	strcat(buffer, "`");
	strcat(buffer, pi);
	strcat(buffer, "");
	strcat(buffer, "`");
	strcat(buffer, l);
	strcat(buffer, "");
	strcat(buffer, "`");
	strcat(buffer, wr);
	strcat(buffer, "");
	strcat(buffer, "`");
	strcat(buffer, ma);
	strcat(buffer, "");
	strcat(buffer, "`");
	strcat(buffer, "");

	float monthlyIncome = atof(mi);
	float monthlyExpenses = atof(me);
	float savings = atof(s);
	float passiveIncome = atof(pi);
	float legacy = atof(l);
	float withdrawalRate = atof(wr);
	withdrawalRate /= 100;
	int maxAge = atoi(ma);
	string stru(u);
	int fireAge = getUserAge(stru);
	int age = fireAge;
	vector<float>sums;

	float sum = savings;
	bool ok = 0;

	//cout << "\n sec1 \n";

	for (int i = age; i < maxAge && ok == 0; i++)
	{
		sum = sum * (1 + withdrawalRate) + (monthlyIncome - monthlyExpenses + passiveIncome) * 12;
		sums.push_back(sum);
		float checksum = sum;

		//cout << "\n sec1.1 \n";
		for (int j = i + 1; j < maxAge && checksum >= legacy; j++)
		{
			checksum = checksum * (1 + withdrawalRate) - (monthlyExpenses -
				passiveIncome) * 12;
		}
		//cout << "\n sec1.2 \n";

		if (checksum >= legacy)
		{
			fireAge = i+1;
			ok = 1;
		}
		//cout << "\n sec1.3 \n";

	}
	//cout << "\n sec2 \n";
	strcat(buffer, to_string(age).c_str());
	strcat(buffer, "`");
	strcat(buffer, to_string(fireAge).c_str());
	strcat(buffer, "`");
	strcat(buffer, to_string(int(sum)).c_str());
	strcat(buffer, "`");
	strcat(buffer, to_string(sums.size()).c_str());
	strcat(buffer, "`");
	strcat(buffer, "");
	//cout << "\n sec3 \n";
	for (int i = 0; i < sums.size(); i++)
	{
		strcat(buffer, to_string(int(sums[i])).c_str());
		strcat(buffer, "`");
	}
	//cout << "\n sec4 \n";

	string query = "INSERT INTO results(id, iduser, monthlyIncome, monthlyExpenses, savings, passiveIncome, legacy, withdrawalRate, age, maxAge) VALUES("
		+ to_string(getLastId("results")) + ", " + to_string(getUserId(stru)) + ", " +
		to_string(monthlyIncome) + ", " + to_string(monthlyExpenses) + ", " + to_string(savings)
		+ ", " + to_string(passiveIncome) + ", " + to_string(legacy) + ", "
		+ to_string(withdrawalRate*100) + ", " +
		to_string(age) + ", " + to_string(maxAge) + ");";
	//cout << "\n sec5 \n";

	if (mysql_query(conn, query.c_str()) != 0)
	{
		buffer[strlen(u) + 3] = '0';
		strcat(buffer, "");
	}
	//cout << "\n sec6 \n";
	//cout << endl << buffer << endl;

	sums.clear();
	stru.clear();

	return buffer;
}

char* Database::save(char* u, char* n)
{
	strcpy(buffer, "s`");
	strcat(buffer, u);
	strcat(buffer, "`");
	strcat(buffer, n);
	strcat(buffer, "`");
	strcat(buffer, "1`");
	strcat(buffer, "");

	string strn(n);
	string stru(u);

	string query = "UPDATE results SET nameResult='" + strn;
	query += "', dateCreation=CURDATE() WHERE nameResult IS NULL AND dateCreation IS NULL AND iduser=" 
		+ to_string(getUserId(stru))+";";

	cout << query << endl;

	mysql_query(conn, query.c_str());
	if (mysql_affected_rows(conn)==0)
	{
		buffer[strlen(buffer) - 2] = '0';
		strcat(buffer, "");
	}

	strn.clear();
	stru.clear();
	query.clear();

	return buffer;
}

char* Database::Delete(char* u, char* n)
{
	strcpy(buffer, "d`");
	strcat(buffer, u);
	strcat(buffer, "`");
	strcat(buffer, n);
	strcat(buffer, "`");
	strcat(buffer, "1`");
	strcat(buffer, "");

	string stru(u);
	string strn(n);
	string query;

	if (strn == "NULL")
	{
		query = "DELETE FROM results WHERE iduser=" + to_string(getUserId(stru));
		query += " AND nameResult IS NULL;";
	}
	else
	{
		query = "DELETE FROM results WHERE iduser=" + to_string(getUserId(stru));
		query += " AND nameResult='" + strn+"';";
	}

	if (mysql_query(conn, query.c_str()) != 0)
	{
		buffer[strlen(buffer) - 2] = '0';
		strcat(buffer, "");
	}

	cout << query << endl;

	stru.clear();
	strn.clear();
	query.clear();

	return buffer;
}

char* Database::getResults(char* u)
{
	strcpy(buffer, "G`");
	strcat(buffer, u);
	strcat(buffer, "`");
	strcat(buffer, "");

	string stru(u);
	char token[1024];
	char* tokken;

	string query = "SELECT nameResult, dateCreation FROM results WHERE nameResult IS NOT NULL AND iduser=" +
		to_string(getUserId(stru)) + ';';

	if (mysql_query(conn, query.c_str()) == 0)
	{
		res = mysql_store_result(conn);
		if (res->row_count > 0)
		{
			row = mysql_fetch_row(res);
			int x = res->row_count;
			strcat(buffer, to_string(x).c_str());
			strcat(buffer, "`");
			strcat(buffer, row[0]);
			strcat(buffer, "`");

			strcpy(token, row[1]);

			tokken = strtok(token, "-");
			while (tokken)
			{
				strcat(buffer, tokken);
				strcat(buffer, "`");
				tokken = strtok(NULL, "-");
			}

			while (row = mysql_fetch_row(res))
			{
				//cout << row[0] << endl << row[1] << endl;
				strcat(buffer, row[0]);
				strcat(buffer, "`");

				strcpy(token, row[1]);

				tokken = strtok(token, "-");
				while (tokken)
				{
					strcat(buffer, tokken);
					strcat(buffer, "`");
					tokken = strtok(NULL, "-");
				}

			}
			//delete token;
			delete tokken;
		}
	}

	stru.clear();
	query.clear();

	//row = nullptr;

	//mysql_free_result(res);


	return buffer;
}

char* Database::changeFirstName(char* u, char* fn)
{
	strcpy(buffer, "7`");
	strcat(buffer, u);
	strcat(buffer, "`1`");
	strcat(buffer, "");

	string stru(u);
	string strfn(fn);

	string query = "INSERT INTO requests(id, type, username, sstring) VALUES("
		+ to_string(getLastId("requests")) + ", 7, '" + stru + "', '" + strfn + "');";

	if (mysql_query(conn, query.c_str()) != 0)
	{
		buffer[strlen(buffer) - 2] = '0';
		strcat(buffer, "");
	}

	stru.clear();
	strfn.clear();
	query.clear();

	return buffer;
}

char* Database::changeLastName(char* u, char* ln)
{
	strcpy(buffer, "6`");
	strcat(buffer, u);
	strcat(buffer, "`1`");
	strcat(buffer, "");

	string stru(u);
	string strln(ln);

	string query = "INSERT INTO requests(id, type, username, sstring) VALUES("
		+ to_string(getLastId("requests")) + ", 6, '" + stru + "', '" + strln + "');";

	if (mysql_query(conn, query.c_str()) != 0)
	{
		buffer[strlen(buffer) - 2] = '0';
		strcat(buffer, "");
	}

	stru.clear();
	strln.clear();
	query.clear();

	return buffer;
}

char* Database::changeBirthdate(char* u, char* d, char* m, char* y)
{
	strcpy(buffer, "8`");
	strcat(buffer, u);
	strcat(buffer, "`1`");
	strcat(buffer, "");

	string stru(u);
	string strd(d);
	string strm(m);
	string stry(y);

	string query = "INSERT INTO requests(id, type, username, sstring) VALUES("
		+ to_string(getLastId("requests")) + ", 8, '" + stru + "', '" + strd + "-" +
		strm + "-" + stry + "');";
	 
	if (mysql_query(conn, query.c_str()) != 0)
	{
		buffer[strlen(buffer) - 2] = '0';
		strcat(buffer, "");
	}

	stru.clear();
	strd.clear();
	strm.clear();
	stry.clear();
	query.clear();

	return buffer;
}

char* Database::DeleteAccount(char* u)
{
	strcpy(buffer, "9`");
	strcat(buffer, u);
	strcat(buffer, "`1`");
	strcat(buffer, "");

	string stru(u);
	
	string query = "DELETE FROM users WHERE username='" + stru + "';";
	if (mysql_query(conn, query.c_str()) != 0)
	{
		buffer[strlen(buffer) - 2] = '0';
		strcat(buffer, "");
	}

	stru.clear();
	query.clear();

	return buffer;
}

char* Database::changePassword(char* u, char* p)
{
	strcpy(buffer, "a`");
	strcat(buffer, u);
	strcat(buffer, "`");
	strcat(buffer, "1`");
	strcat(buffer, "");

	string stru(u);
	string strp(p);

	string query = "UPDATE users SET password='" + strp + "' WHERE username='" + stru + "';";

	mysql_query(conn, query.c_str());
	if (mysql_affected_rows(conn) == 0)
	{
		buffer[strlen(buffer) - 2] = '0';
		strcat(buffer, "");
	}

	stru.clear();
	strp.clear();
	query.clear();

	return buffer;
}

char* Database::getSavedResult(char* u, char* n)
{

	string stru(u);
	string strn(n);

	string query = "SELECT * FROM results WHERE iduser='"+to_string(getUserId(stru))
		+"' AND nameResult='"+strn+"';";
	if (mysql_query(conn, query.c_str()) == 0)
	{
		res = mysql_store_result(conn);
		row = mysql_fetch_row(res);
		float wr = atof(row[7]);
		char c[5];
		strcpy(c, to_string(int(wr)).c_str());
		strcpy(buffer, generateResult(u, row[2], row[3], row[4], row[5], row[6], c, row[9]));
		buffer[0] = 'g';
	}
	else
	{
		strcpy(buffer, "g`");
		strcat(buffer, u);
		strcat(buffer, "`0`");
	}

	return buffer;
}

char* Database::getRequests()
{
	strcpy(buffer, "r`");
	strcat(buffer, "");


	string query = "SELECT type, username, sstring FROM requests;";

	if (mysql_query(conn, query.c_str()) == 0)
	{
		res = mysql_store_result(conn);
		if (res->row_count > 0)
		{
			int x = res->row_count;
			strcat(buffer, to_string(x).c_str());
			strcat(buffer, "`");
			while (x)
			{
				row = mysql_fetch_row(res);
				strcat(buffer, row[0]);
				strcat(buffer, "`");
				strcat(buffer, row[1]);
				strcat(buffer, "`");
				strcat(buffer, row[2]);
				strcat(buffer, "`");
				x--;
			}
		}
	}

	query.clear();

	return buffer;
}

char* Database::getUsers()
{
	strcpy(buffer, "u`");
	strcat(buffer, "");

	string query = "SELECT username FROM users WHERE id IS NOT NULL;";

	if (mysql_query(conn, query.c_str()) == 0)
	{
		res = mysql_store_result(conn);
		if (res->row_count > 0)
		{
			int x = res->row_count;
			strcat(buffer, to_string(x).c_str());
			strcat(buffer, "`");
			while (x)
			{
				row = mysql_fetch_row(res);
				strcat(buffer, row[0]);
				strcat(buffer, "`");
				x--;
			}
		}
	}

	query.clear();

	return buffer;
}
#pragma once
#include "Request.h"
class RequestGenerateResult :
    public Request
{
public:
    RequestGenerateResult(){}
    ~RequestGenerateResult(){}

    virtual char* execute(vector<char*>v) override
    {
        strcpy(buffer, Database::getInstance().generateResult(v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8]));

        return buffer;
    }
};
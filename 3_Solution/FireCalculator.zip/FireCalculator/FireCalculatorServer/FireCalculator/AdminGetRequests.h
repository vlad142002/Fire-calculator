#pragma once
#include "AdminResponse.h"
class AdminGetRequests :
    public AdminResponse
{
public:
    AdminGetRequests(){}
    ~AdminGetRequests() {}

    virtual char* execute() override
    {
        strcpy(buffer, Database::getInstance().getRequests());

        return buffer;
    }
};


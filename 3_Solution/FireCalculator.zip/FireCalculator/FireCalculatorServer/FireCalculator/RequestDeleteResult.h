#pragma once
#include "Request.h"
class RequestDeleteResult :
    public Request
{
public:
    RequestDeleteResult(){}
    ~RequestDeleteResult(){}

    virtual char* execute(vector<char*> v) override
    {
        strcpy(buffer, Database::getInstance().Delete(v[1], v[2]));

        return buffer;
    }
};


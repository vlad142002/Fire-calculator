#pragma once
#include "Request.h"
class RequestSavedResult :
    public Request
{
public:
    RequestSavedResult() {}
    ~RequestSavedResult() {}

    virtual char* execute(vector<char*> v) override
    {
        strcpy(buffer, Database::getInstance().getSavedResult(v[1], v[2]));
   
        return buffer;
    }
};


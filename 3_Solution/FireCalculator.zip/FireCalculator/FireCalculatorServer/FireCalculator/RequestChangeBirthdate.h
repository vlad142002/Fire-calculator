#pragma once
#include "Request.h"
class RequestChangeBirthdate :
    public Request
{
public:
    RequestChangeBirthdate(){}
    ~RequestChangeBirthdate(){}

    virtual char* execute(vector<char*> v) override
    {
        
        strcpy(buffer,Database::getInstance().changeBirthdate(v[1], v[2], v[3], v[4]));

        return buffer;
    }
};


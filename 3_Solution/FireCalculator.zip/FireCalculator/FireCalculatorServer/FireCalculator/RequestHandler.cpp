#define _CRT_SECURE_NO_WARNINGS
#include "RequestHandler.h"

char* RequestHandler::chooseRequest(char* r)
{
    char buffer[1024];

    token = strtok(r, "` .,");
    while (token != NULL)
    {
        parameters.push_back(token);
        token = strtok(NULL, "`");
    }
    switch (parameters[0][0])
    {
    case '1':
    {
        IRequest* i1 = nullptr;
        i1 = Factory::factoryStaticMethod(Factory::Request::checkUsernameAndPassword);
        if (i1 != nullptr)
        {
            strcpy(buffer,i1->execute(parameters));
            strcat(buffer, "");
        }
        delete i1;
    }
        break;
    case '2':
    {
        IRequest* i2 =nullptr;
        i2 = Factory::factoryStaticMethod(Factory::Request::checkIfUserExists);
        if (i2 != nullptr)
        {
            strcpy(buffer, i2->execute(parameters));
            strcat(buffer, "");
        }
        delete i2;
    }
        break;
    case '3':
    {
        IRequest* i3 = nullptr;
        i3 = Factory::factoryStaticMethod(Factory::Request::createAccount);
        if (i3 != nullptr)
        {
            strcpy(buffer, i3->execute(parameters));
            strcat(buffer, "");
        }
        delete i3;
    }
        break;
    case '4':
    {
        IRequest* i4 = nullptr;
        i4= Factory::factoryStaticMethod(Factory::Request::getUserData);
        if (i4 != nullptr)
        {
            strcpy(buffer, i4->execute(parameters));
            strcat(buffer, "");
        }
        delete i4;
    }
        break;
    case 'x':
    {
        IRequest* ix = nullptr;
        ix= Factory::factoryStaticMethod(Factory::Request::generateResult);
        if (ix != nullptr)
        {
            strcpy(buffer, ix->execute(parameters));
            strcat(buffer, "");
        }
        delete ix;
    }
        break;
    case 's':
    {
        IRequest* is = nullptr;
        is= Factory::factoryStaticMethod(Factory::Request::saveResult);
        if (is != nullptr)
        {
            strcpy(buffer, is->execute(parameters));
            strcat(buffer, "");
        }
        delete is;
    }
        break;
    case 'd':
    {
        IRequest* id = nullptr;
        id= Factory::factoryStaticMethod(Factory::Request::deleteResult);
        if (id != nullptr)
        {
            strcpy(buffer, id->execute(parameters));
            strcat(buffer, "");
        }
        delete id;
    }
        break;
    case 'G':
    {
        IRequest* iG = nullptr;
        iG = Factory::factoryStaticMethod(Factory::Request::getResults);
        if (iG != nullptr)
        {
            strcpy(buffer, iG->execute(parameters));
            strcat(buffer, "");
        }
        delete iG;
    }
        break;
    case '6':
    {
        IRequest* icl = nullptr;
        icl = Factory::factoryStaticMethod(Factory::Request::changeLastName);
        if (icl != nullptr)
        {
            strcpy(buffer, icl->execute(parameters));
            strcat(buffer, "");
        }
        delete icl;

    }
    break;
    case '7':
    {
        IRequest* icf = nullptr;
        icf = Factory::factoryStaticMethod(Factory::Request::changeFirstName);
        if (icf != nullptr)
        {
            strcpy(buffer, icf->execute(parameters));
            strcat(buffer, "");
        }
        delete icf;

    }
    break;
    case '8':
    {
        IRequest* icd = nullptr;
        icd = Factory::factoryStaticMethod(Factory::Request::changeBirthdate);
        if (icd != nullptr)
        {
            strcpy(buffer, icd->execute(parameters));
            strcat(buffer, "");
        }
        delete icd;
    }
    case '9':
    {
        IRequest* ida = nullptr;
        ida = Factory::factoryStaticMethod(Factory::Request::deleteAccount);
        if (ida != nullptr)
        {
            strcpy(buffer, ida->execute(parameters));
            strcat(buffer, "");
        }
        delete ida;
    }
    break;
    case 'a':
    {
        IRequest* icp = nullptr;
        icp = Factory::factoryStaticMethod(Factory::Request::changePassword);
        if (icp != nullptr)
        {
            strcpy(buffer, icp->execute(parameters));
            strcat(buffer, "");
        }
        delete icp;
    }
    break;
    case 'g':
    {
        IRequest* isr = nullptr;
        isr = Factory::factoryStaticMethod(Factory::Request::savedResult);
        if (isr != nullptr)
        {
            strcpy(buffer, isr->execute(parameters));
            strcat(buffer, "");
        }
        delete isr;

    }
    break;
    case 'r':
    {
        IAdminResponse* igr = nullptr;
        igr = FactoryAdmin::factoryAdminStaticMethod(FactoryAdmin::Response::getRequest);
        if (igr != nullptr)
        {
            strcpy(buffer, igr->execute());
            strcat(buffer, "");
        }
        delete igr;
    }
    break;
    case 'u':
    {
        IAdminResponse* igu = nullptr;
        igu = FactoryAdmin::factoryAdminStaticMethod(FactoryAdmin::Response::getUsers);
        if (igu != nullptr)
        {
            strcpy(buffer, igu->execute());
            strcat(buffer, "");
        }
        delete igu;
    }
    break;
        

    default:
        cout << "Eroare la protocolul: " << parameters[0][0] << endl;
        strcpy(buffer, "Eroare!!!");
        break;
    }

    parameters.clear();

    return buffer;
}
